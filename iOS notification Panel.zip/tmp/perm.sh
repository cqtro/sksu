#!/sbin/busybox sh

chmod 777 /data/tmp/vrtheme/zipalign
chmod 777 /data/tmp/vrtheme/zip
chmod 777 /data/tmp/vrtheme/installtheme.sh