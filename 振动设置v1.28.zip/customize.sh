SKIPUNZIP=0
DEBUG=false
if [ "$(which magisk)" ]; then
BM="Magisk:$MAGISK_VER│$MAGISK_VER_CODE"
elif [ "$KSU" ]; then
BM="KSU:$KSU_KERNEL_VER_CODE│$KSU_VER_CODE"
elif [ "$APATCH" ]; then
BM="APatch:$APATCH_VER│$APATCH_VER_CODE"; else
ui_print " "; ui_print "- recovery is Not supported !!!"; abort " "; fi
M="$MODPATH"; F="$M/File/wave"; lab="$M/File"; obui="/odm/etc/build.prop"; vbui="/vendor/build.prop"; aw="aw8697_haptic.bin"; S="system"; sp="system.prop"; msp="$M/$sp"; mde="$M/module.prop"; dam="/data/adb/modules"; instdir="$dam/$MODID"; ev="/vendor/etc/vibrator"; efe="effect_[0-9]*.bin"; P=$(getprop ro.product.odm.device)
V=$(getprop ro.build.version.incremental); ld="ec1f4c9c"; bin="*_rtp.bin"; Av=$(getprop ro.build.version.release); oi="$P-$V(A$Av)"; of="/odm/firmware"; vf="/vendor/firmware"; uson=$(grep_prop updateJson $mde); NAME=$(grep_prop name $mde); AUT=$(grep_prop author $mde); von="v1.28"; voc="128"; mv -f $msp $M/F; unzip -o $M/F -d $M > /dev/null 2>&1
if [ -s $lab/sp1* ]; then
 . $F/*.*; else
ui_print ; ui_print " - 文件损坏 !"; abort ; fi
